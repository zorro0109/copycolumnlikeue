import sublime
import sublime_plugin


class columncopylikeue(sublime_plugin.TextCommand):
	def run(self, edit):
		# self.view.insert(edit, 0, "Hello, World!")
		clipboard = sublime.get_clipboard()
		strs = clipboard.split("\n")
		view = self.view
		selection  = view.sel()
		if selection:
			i = 0
			for region in selection:
				self.view.insert(edit, region.begin(), strs[i])
				i += 1
				if i >= len(strs):
					break